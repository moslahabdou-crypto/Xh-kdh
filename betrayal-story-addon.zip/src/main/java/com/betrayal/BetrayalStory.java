package com.betrayal;

import com.betrayal.entity.BetrayalEntity;
import com.betrayal.entity.BetrayalGhostEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/**
 * Betrayal 1.1 - the continuation.
 *
 * Everything lives in this one file and registers itself, so no existing file has to be edited.
 * It reads the old save keys (betrayal_killed / betrayal_haunt / betrayal_day) and uses the old
 * entities (BetrayalEntity = the friend, BetrayalGhostEntity = the spirit).
 *
 * Story order (all numbers are constants below):
 *   night 1..6  : the spirit haunts, strange things happen, the house may turn to Bedrock
 *   night 7+    : the "Guardian" (you, from the future) appears every 20 min and protects you for 5 min
 *   night 8     : the spirit whispers how to make the Crescent & Star
 *   night 12+   : with the Crescent placed in your house, the truth comes out -> boss fight -> friend returns
 */
public final class BetrayalStory {
    public static final String MODID = "betrayal";

    // ---- story constants (change these freely) ----
    static final int FUTURE_NIGHT = 7;      // first night the Guardian shows up
    static final int WHISPER_NIGHT = 8;     // spirit explains the Crescent
    static final int REVEAL_NIGHT = 12;     // earliest night for the final confrontation
    static final long GUARD_PERIOD = 24000L; // 20 minutes
    static final long GUARD_LENGTH = 6000L;  // 5 minutes
    static final String TAG_RESTORED = "betrayal_restored";

    public static Block CRESCENT;
    public static Item CRESCENT_ITEM;
    public static EntityType<FutureEntity> FUTURE;

    private BetrayalStory() {}

    // =====================================================================================
    //  State helpers
    // =====================================================================================

    static CompoundTag st(ServerPlayer p) {
        CompoundTag d = p.getPersistentData();
        if (!d.contains("betrayal_story", 10)) {
            d.put("betrayal_story", new CompoundTag());
        }
        return d.getCompound("betrayal_story");
    }

    static BlockPos posOf(CompoundTag st, String key) {
        return st.contains(key) ? BlockPos.of(st.getLong(key)) : null;
    }

    static boolean crescentOk(ServerLevel l, CompoundTag st) {
        BlockPos c = posOf(st, "crescent");
        return c != null && l.isLoaded(c) && l.getBlockState(c).is(CRESCENT);
    }

    static boolean enclosed(ServerLevel l, BlockPos pos) {
        BlockPos eye = pos.above();
        if (l.canSeeSky(eye)) {
            return false;
        }
        int walls = 0;
        for (Direction d : Direction.Plane.HORIZONTAL) {
            for (int i = 1; i <= 8; i++) {
                BlockState s = l.getBlockState(eye.relative(d, i));
                if (s.canOcclude()) {
                    walls++;
                    break;
                }
            }
        }
        return walls >= 3;
    }

    static boolean isBuilding(BlockState s) {
        return s.is(BlockTags.PLANKS) || s.is(BlockTags.LOGS) || s.is(BlockTags.WOODEN_STAIRS)
                || s.is(BlockTags.WOODEN_SLABS) || s.is(BlockTags.WOODEN_DOORS) || s.is(BlockTags.WOODEN_TRAPDOORS)
                || s.is(BlockTags.WOODEN_FENCES) || s.is(BlockTags.WOOL) || s.is(BlockTags.STONE_BRICKS)
                || s.is(BlockTags.STAIRS) || s.is(BlockTags.SLABS) || s.is(BlockTags.WALLS)
                || s.is(BlockTags.DOORS) || s.is(BlockTags.IMPERMEABLE) || s.is(Tags.Blocks.GLASS_PANES)
                || s.is(Blocks.COBBLESTONE) || s.is(Blocks.BRICKS) || s.is(Blocks.SMOOTH_STONE);
    }

    // ---- messages ----

    static void say(ServerPlayer p, String name, String text, ChatFormatting nameColor) {
        p.sendSystemMessage(Component.literal("<" + name + "> ").withStyle(nameColor)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE)));
    }

    static void narrate(ServerPlayer p, String text) {
        p.sendSystemMessage(Component.literal(text).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
    }

    static void title(ServerPlayer p, String main, String sub, ChatFormatting color, int in, int stay, int out) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(in, stay, out));
        p.connection.send(new ClientboundSetSubtitleTextPacket(
                Component.literal(sub == null ? "" : sub).withStyle(ChatFormatting.GRAY)));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(main).withStyle(color, ChatFormatting.BOLD)));
    }

    static void sound(ServerLevel l, double x, double y, double z, SoundEvent s, float vol, float pitch) {
        l.playSound(null, x, y, z, s, SoundSource.AMBIENT, vol, pitch);
    }

    static void scary(ServerPlayer p) {
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), BetrayalMod.SCARY_VOICE.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
    }

    static void promptGender(ServerPlayer p) {
        Component boy = Component.literal("[Boy]").withStyle(Style.EMPTY.withColor(ChatFormatting.AQUA)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/betrayal gender boy")));
        Component girl = Component.literal("[Girl]").withStyle(Style.EMPTY.withColor(ChatFormatting.LIGHT_PURPLE)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/betrayal gender girl")));
        p.sendSystemMessage(Component.literal("Betrayal: are you a boy or a girl? It decides whether your Crescent & Star is silver or gold. ")
                .withStyle(ChatFormatting.GRAY).append(boy).append(Component.literal(" ")).append(girl));
    }

    // =====================================================================================
    //  Timed scripts (sequences of messages/events with delays, in ticks)
    // =====================================================================================

    static final class Step {
        int delay;
        final Consumer<ServerPlayer> act;

        Step(int delay, Consumer<ServerPlayer> act) {
            this.delay = delay;
            this.act = act;
        }
    }

    static final Map<UUID, ArrayDeque<Step>> SCRIPTS = new HashMap<>();

    static Step at(int delay, Consumer<ServerPlayer> act) {
        return new Step(Math.max(1, delay), act);
    }

    static void play(ServerPlayer p, List<Step> steps) {
        SCRIPTS.put(p.getUUID(), new ArrayDeque<>(steps));
    }

    static boolean hasScript(ServerPlayer p) {
        ArrayDeque<Step> q = SCRIPTS.get(p.getUUID());
        return q != null && !q.isEmpty();
    }

    static void runScripts(ServerPlayer p) {
        ArrayDeque<Step> q = SCRIPTS.get(p.getUUID());
        if (q == null || q.isEmpty()) {
            return;
        }
        Step s = q.peek();
        if (--s.delay <= 0) {
            q.poll();
            s.act.accept(p);
        }
    }

    static List<Step> typewriter(String text) {
        List<Step> l = new ArrayList<>();
        for (int i = 1; i <= text.length(); i++) {
            final String sub = text.substring(0, i);
            l.add(at(3, pl -> pl.displayClientMessage(Component.literal(sub).withStyle(ChatFormatting.DARK_RED), true)));
        }
        l.add(at(60, pl -> pl.displayClientMessage(Component.empty(), true)));
        return l;
    }

    // =====================================================================================
    //  Bedrock house (with backup so everything comes back)
    // =====================================================================================

    public static class Backup extends SavedData {
        final Map<Long, BlockState> map = new HashMap<>();

        static Backup get(ServerLevel l) {
            return l.getDataStorage().computeIfAbsent(Backup::load, Backup::new, "betrayal_bedrock");
        }

        static Backup load(CompoundTag t) {
            Backup b = new Backup();
            ListTag list = t.getList("b", 10);
            for (Tag x : list) {
                CompoundTag c = (CompoundTag) x;
                b.map.put(c.getLong("p"), NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), c.getCompound("s")));
            }
            return b;
        }

        @Override
        public CompoundTag save(CompoundTag t) {
            ListTag list = new ListTag();
            for (Map.Entry<Long, BlockState> en : map.entrySet()) {
                CompoundTag c = new CompoundTag();
                c.putLong("p", en.getKey());
                c.put("s", NbtUtils.writeBlockState(en.getValue()));
                list.add(c);
            }
            t.put("b", list);
            return t;
        }
    }

    static void convertHouse(ServerLevel l, BlockPos home, BlockPos skip) {
        Backup b = Backup.get(l);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = -9; x <= 9; x++) {
            for (int y = -3; y <= 9; y++) {
                for (int z = -9; z <= 9; z++) {
                    m.set(home.getX() + x, home.getY() + y, home.getZ() + z);
                    if (skip != null && m.equals(skip)) {
                        continue;
                    }
                    BlockState s = l.getBlockState(m);
                    if (isBuilding(s) && l.getBlockEntity(m) == null) {
                        b.map.put(m.asLong(), s);
                        l.setBlock(m, Blocks.BEDROCK.defaultBlockState(), 2);
                    }
                }
            }
        }
        b.setDirty();
    }

    static void restoreHouse(ServerLevel l) {
        Backup b = Backup.get(l);
        Iterator<Map.Entry<Long, BlockState>> it = b.map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Long, BlockState> en = it.next();
            BlockPos p = BlockPos.of(en.getKey());
            if (!l.isLoaded(p)) {
                continue;
            }
            if (l.getBlockState(p).is(Blocks.BEDROCK)) {
                l.setBlock(p, en.getValue(), 2);
            }
            it.remove();
        }
        b.setDirty();
    }

    // =====================================================================================
    //  Ghost / guardian helpers
    // =====================================================================================

    /** Keeps the old spirit away (used while the Guardian protects you, and during the finale). */
    static void suppressGhost(ServerPlayer p, ServerLevel l) {
        CompoundTag d = p.getPersistentData();
        d.putBoolean("betrayal_haunt", false);
        d.putLong("betrayal_day", l.getDayTime() / 24000L + 1);
        for (BetrayalGhostEntity g : l.getEntitiesOfClass(BetrayalGhostEntity.class, p.getBoundingBox().inflate(128),
                g -> p.getUUID().equals(g.getOwnerId()))) {
            g.discard();
        }
    }

    static List<FutureEntity> futures(ServerPlayer p, ServerLevel l) {
        return l.getEntitiesOfClass(FutureEntity.class, p.getBoundingBox().inflate(96),
                f -> p.getUUID().equals(f.getOwnerUuid()));
    }

    static FutureEntity spawnFuture(ServerPlayer p, ServerLevel l, int mode) {
        FutureEntity f = FUTURE.create(l);
        if (f == null) {
            return null;
        }
        Vec3 look = Vec3.directionFromRotation(0, p.getYRot()).scale(3.0);
        f.moveTo(p.getX() + look.x, p.getY(), p.getZ() + look.z, p.getYRot() + 180.0F, 0.0F);
        f.setOwner(p.getUUID());
        f.setMode(mode);
        l.addFreshEntity(f);
        l.sendParticles(ParticleTypes.SMOKE, f.getX(), f.getY() + 1.0, f.getZ(), 20, 0.3, 0.6, 0.3, 0.02);
        return f;
    }

    static void fadeFutures(ServerPlayer p, ServerLevel l) {
        for (FutureEntity f : futures(p, l)) {
            l.sendParticles(ParticleTypes.LARGE_SMOKE, f.getX(), f.getY() + 1.0, f.getZ(), 25, 0.3, 0.7, 0.3, 0.02);
            f.discard();
        }
    }

    // ---- the Guardian (every 20 min, for 5 min) ----

    static final String[] GUARD_LINES = {
            "Don't look at him. Look at me.",
            "You'll understand later. Just stay alive.",
            "I did this once too.",
            "He isn't angry. That's the worst part.",
            "Five minutes. Use them.",
            "Keep walking. Don't turn around."
    };

    static void startGuard(ServerPlayer p, ServerLevel l, CompoundTag st, long gt) {
        CompoundTag d = p.getPersistentData();
        st.putBoolean("guardOn", true);
        st.putBoolean("hauntBefore", d.getBoolean("betrayal_haunt"));
        st.putLong("guardEnd", gt + GUARD_LENGTH);
        st.putLong("guardNext", gt + GUARD_PERIOD);
        int count = st.getInt("guards") + 1;
        st.putInt("guards", count);
        suppressGhost(p, l);
        spawnFuture(p, l, 0);
        scary(p);
        title(p, "WHY DID YOU DO THIS?", null, ChatFormatting.DARK_RED, 10, 70, 30);
        final String me = p.getName().getString();
        List<Step> s = new ArrayList<>();
        if (count == 1) {
            s.add(at(80, pl -> say(pl, me, "Don't look at him. Look at me.", ChatFormatting.WHITE)));
            s.add(at(70, pl -> say(pl, me, "Yes. Your face. Your hands. Your knife.", ChatFormatting.WHITE)));
            s.add(at(80, pl -> say(pl, me, "I'm you. Later. Don't ask me how much later.", ChatFormatting.WHITE)));
            s.add(at(80, pl -> say(pl, me, "I can hold him for five minutes. I'll come back every twenty.", ChatFormatting.WHITE)));
        } else {
            final String line = GUARD_LINES[count % GUARD_LINES.length];
            s.add(at(80, pl -> say(pl, me, line, ChatFormatting.WHITE)));
        }
        if (crescentOk(l, st) && !st.getBoolean("warned")) {
            st.putBoolean("warned", true);
            s.add(at(90, pl -> say(pl, me, "Take it out. Now.", ChatFormatting.WHITE)));
        }
        play(p, s);
    }

    static void endGuard(ServerPlayer p, ServerLevel l, CompoundTag st) {
        st.putBoolean("guardOn", false);
        fadeFutures(p, l);
        if (p.getPersistentData().getBoolean("betrayal_killed")) {
            p.getPersistentData().putBoolean("betrayal_haunt", st.getBoolean("hauntBefore"));
        }
        narrate(p, "He is gone. The air is cold again.");
    }

    // ---- the reveal and the boss fight ----

    static void startReveal(ServerPlayer p, ServerLevel l, CompoundTag st) {
        st.putInt("stage", 1);
        st.putBoolean("guardOn", false);
        suppressGhost(p, l);
        fadeFutures(p, l);
        final String me = p.getName().getString();
        List<Step> s = new ArrayList<>();
        s.add(at(1, pl -> {
            scary(pl);
            title(pl, "WHY DID YOU DO THIS?", null, ChatFormatting.DARK_RED, 10, 70, 30);
        }));
        s.add(at(90, pl -> narrate(pl, "The crescent hums. For the first time, the air is warm.")));
        s.add(at(80, pl -> say(pl, "The Betrayed", "He was never here to save you.", ChatFormatting.AQUA)));
        s.add(at(70, pl -> spawnFuture(pl, pl.serverLevel(), 1)));
        s.add(at(70, pl -> say(pl, me, "I told you to take it out.", ChatFormatting.WHITE)));
        s.add(at(70, pl -> say(pl, me, "If he comes back, I was never needed.", ChatFormatting.WHITE)));
        s.add(at(70, pl -> narrate(pl, "You: \"You're me.\"")));
        s.add(at(60, pl -> say(pl, me, "No. I'm what's left of you.", ChatFormatting.WHITE)));
        s.add(at(80, pl -> say(pl, me, "I only stood between you and him so you'd never have to answer.", ChatFormatting.WHITE)));
        s.add(at(80, pl -> say(pl, me, "I'm sorry. I can't let you.", ChatFormatting.WHITE)));
        s.add(at(50, pl -> startBoss(pl)));
        play(p, s);
    }

    static void startBoss(ServerPlayer p) {
        ServerLevel l = p.serverLevel();
        CompoundTag st = st(p);
        st.putInt("stage", 2);
        FutureEntity boss = null;
        for (FutureEntity f : futures(p, l)) {
            boss = f;
            break;
        }
        if (boss == null) {
            boss = spawnFuture(p, l, 2);
        }
        if (boss != null) {
            boss.setMode(2);
            boss.setHealth(boss.getMaxHealth());
        }
        if (p.getInventory().countItem(BetrayalMod.KNIFE.get()) == 0) {
            p.addItem(new ItemStack(BetrayalMod.KNIFE.get()));
        }
        scary(p);
        title(p, "ENOUGH.", "Only the knife can end this.", ChatFormatting.DARK_RED, 5, 40, 20);
    }

    static void startEnding(ServerPlayer p) {
        CompoundTag st = st(p);
        st.putInt("stage", 3);
        final String me = p.getName().getString();
        List<Step> s = new ArrayList<>();
        s.add(at(1, pl -> {
            suppressGhost(pl, pl.serverLevel());
            sound(pl.serverLevel(), pl.getX(), pl.getY(), pl.getZ(), SoundEvents.BEACON_DEACTIVATE, 1.0F, 0.7F);
            narrate(pl, "He doesn't fall. He fades, the way a held breath does.");
        }));
        s.add(at(70, pl -> say(pl, me, "I only existed because you never answered him.", ChatFormatting.WHITE)));
        s.add(at(70, pl -> say(pl, me, "So answer.", ChatFormatting.WHITE)));
        s.add(at(80, pl -> returnFriend(pl)));
        s.add(at(90, pl -> narrate(pl, "You: \"I'm sorry.\"")));
        s.add(at(70, pl -> say(pl, "The Betrayed", "That's all I wanted.", ChatFormatting.AQUA)));
        s.add(at(80, pl -> say(pl, "The Betrayed", "You didn't have to carry it alone.", ChatFormatting.AQUA)));
        s.add(at(100, pl -> finishEnding(pl)));
        play(p, s);
    }

    static void returnFriend(ServerPlayer p) {
        ServerLevel l = p.serverLevel();
        CompoundTag d = p.getPersistentData();
        d.putBoolean("betrayal_killed", false);
        d.putBoolean("betrayal_haunt", false);
        BetrayalEntity f = BetrayalMod.BETRAYED.get().create(l);
        if (f != null) {
            Vec3 look = Vec3.directionFromRotation(0, p.getYRot()).scale(2.0);
            f.moveTo(p.getX() + look.x, p.getY(), p.getZ() + look.z, p.getYRot() + 180.0F, 0.0F);
            f.setOwnerId(p.getUUID());
            f.addTag(TAG_RESTORED);
            l.addFreshEntity(f);
            l.sendParticles(ParticleTypes.END_ROD, f.getX(), f.getY() + 1.0, f.getZ(), 40, 0.3, 0.8, 0.3, 0.03);
        }
        sound(l, p.getX(), p.getY(), p.getZ(), SoundEvents.BELL_BLOCK, 1.5F, 0.8F);
        title(p, "HE IS BACK", "Forgiveness can't be taken. Only given.", ChatFormatting.GOLD, 10, 80, 30);
    }

    static void finishEnding(ServerPlayer p) {
        ServerLevel l = p.serverLevel();
        CompoundTag st = st(p);
        restoreHouse(l);
        st.putInt("stage", 4);
        st.putBoolean("restored", true);
        l.setDayTime((l.getDayTime() / 24000L + 1L) * 24000L);
        title(p, "Some things can't be undone.", "But they can be answered.", ChatFormatting.GOLD, 20, 100, 40);
    }

    // =====================================================================================
    //  Night events
    // =====================================================================================

    static void onNight(ServerPlayer p, ServerLevel l, CompoundTag st, int n, long gt) {
        switch (n) {
            case 2:
                narrate(p, "Someone is standing at the edge of the trees. Watching.");
                break;
            case 3: {
                narrate(p, "Your footsteps have an echo.");
                List<Step> s = new ArrayList<>();
                for (int i = 0; i < 6; i++) {
                    s.add(at(24, pl -> {
                        Vec3 back = Vec3.directionFromRotation(0, pl.getYRot() + 180.0F).scale(3.0);
                        sound(pl.serverLevel(), pl.getX() + back.x, pl.getY(), pl.getZ() + back.z, SoundEvents.GRASS_STEP, 0.9F, 0.8F);
                    }));
                }
                play(p, s);
                break;
            }
            case 4:
                openNearestDoor(p, l);
                break;
            case 5:
                p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 240, 0, false, false));
                narrate(p, "The light remembers him.");
                break;
            case 6:
                play(p, typewriter("I was still following you."));
                break;
            case FUTURE_NIGHT:
                st.putLong("guardNext", gt);
                break;
            case WHISPER_NIGHT:
                say(p, "The Betrayed", "Make it. Iron. Glass. Coal. Put it where you sleep.", ChatFormatting.AQUA);
                break;
            default:
                break;
        }
    }

    static void openNearestDoor(ServerPlayer p, ServerLevel l) {
        BlockPos best = null;
        double bd = 1.0E9;
        BlockPos c = p.blockPosition();
        for (BlockPos q : BlockPos.betweenClosed(c.offset(-12, -4, -12), c.offset(12, 4, 12))) {
            BlockState s = l.getBlockState(q);
            if (s.getBlock() instanceof DoorBlock && s.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER && !s.getValue(DoorBlock.OPEN)) {
                double dd = q.distSqr(c);
                if (dd < bd) {
                    bd = dd;
                    best = q.immutable();
                }
            }
        }
        if (best != null) {
            BlockState s = l.getBlockState(best);
            ((DoorBlock) s.getBlock()).setOpen(null, l, s, best, true);
            narrate(p, "A door opened by itself.");
        }
    }

    // =====================================================================================
    //  Registration (self-contained, no edits to BetrayalMod needed)
    // =====================================================================================

    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class Reg {
        @SubscribeEvent
        public static void register(RegisterEvent e) {
            e.register(ForgeRegistries.Keys.BLOCKS, h -> {
                CRESCENT = new CrescentBlock();
                h.register(new ResourceLocation(MODID, "crescent"), CRESCENT);
            });
            e.register(ForgeRegistries.Keys.ITEMS, h -> {
                CRESCENT_ITEM = new CrescentItem(CRESCENT, new Item.Properties());
                h.register(new ResourceLocation(MODID, "crescent"), CRESCENT_ITEM);
            });
            e.register(ForgeRegistries.Keys.ENTITY_TYPES, h -> {
                FUTURE = EntityType.Builder.of(FutureEntity::new, MobCategory.MISC)
                        .sized(0.6F, 1.8F).clientTrackingRange(10).build("future");
                h.register(new ResourceLocation(MODID, "future"), FUTURE);
            });
        }

        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent e) {
            e.put(FUTURE, FutureEntity.attrs().build());
        }

        @SubscribeEvent
        public static void tabs(BuildCreativeModeTabContentsEvent e) {
            if (e.getTabKey() == CreativeModeTabs.INGREDIENTS) {
                ItemStack silver = new ItemStack(CRESCENT_ITEM);
                silver.getOrCreateTag().putString("Maker", "boy");
                silver.getOrCreateTag().putBoolean("Gold", false);
                ItemStack gold = new ItemStack(CRESCENT_ITEM);
                gold.getOrCreateTag().putString("Maker", "girl");
                gold.getOrCreateTag().putBoolean("Gold", true);
                e.accept(silver);
                e.accept(gold);
            }
        }
    }

    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientReg {
        @SubscribeEvent
        public static void setup(FMLClientSetupEvent e) {
            e.enqueueWork(() -> ItemProperties.register(CRESCENT_ITEM, new ResourceLocation(MODID, "gold"),
                    (stack, level, entity, seed) -> isGold(stack) ? 1.0F : 0.0F));
        }

        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerEntityRenderer(FUTURE, FutureRenderer::new);
        }
    }

    static boolean isGold(ItemStack s) {
        return s.hasTag() && s.getTag().getBoolean("Gold");
    }

    // =====================================================================================
    //  Crescent & Star (block + item)
    // =====================================================================================

    public static class CrescentBlock extends Block {
        public static final BooleanProperty GOLD = BooleanProperty.create("gold");
        private static final VoxelShape SHAPE = Block.box(1.0, 0.0, 1.0, 15.0, 1.0, 15.0);

        public CrescentBlock() {
            super(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(0.5F).noOcclusion()
                    .lightLevel(s -> 8).sound(SoundType.METAL).pushReaction(PushReaction.DESTROY));
            registerDefaultState(stateDefinition.any().setValue(GOLD, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(GOLD);
        }

        @Override
        public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) {
            return SHAPE;
        }

        @Override
        public boolean canSurvive(BlockState s, LevelReader l, BlockPos p) {
            BlockPos below = p.below();
            return l.getBlockState(below).isFaceSturdy(l, below, Direction.UP);
        }

        @Override
        public BlockState updateShape(BlockState s, Direction d, BlockState n, net.minecraft.world.level.LevelAccessor l,
                BlockPos p, BlockPos np) {
            return !s.canSurvive(l, p) ? Blocks.AIR.defaultBlockState() : s;
        }
    }

    public static class CrescentItem extends BlockItem {
        public CrescentItem(Block b, Item.Properties p) {
            super(b, p);
        }

        @Override
        protected BlockState getPlacementState(BlockPlaceContext ctx) {
            BlockState s = super.getPlacementState(ctx);
            if (s == null) {
                return null;
            }
            return s.setValue(CrescentBlock.GOLD, isGold(ctx.getItemInHand()));
        }

        @Override
        public Component getName(ItemStack stack) {
            return Component.literal(isGold(stack) ? "Crescent & Star (Gold)" : "Crescent & Star (Silver)");
        }
    }

    // =====================================================================================
    //  The Guardian / final enemy: you, from the future
    // =====================================================================================

    public static class FutureEntity extends PathfinderMob {
        private static final EntityDataAccessor<Optional<UUID>> OWNER =
                SynchedEntityData.defineId(FutureEntity.class, EntityDataSerializers.OPTIONAL_UUID);

        private int mode; // 0 = protecting you, 1 = talking (reveal), 2 = final boss
        private int phase = 1;
        private boolean saidLast;
        private final ServerBossEvent bar = new ServerBossEvent(Component.literal("The Guardian"),
                BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.PROGRESS);

        public FutureEntity(EntityType<? extends FutureEntity> type, Level level) {
            super(type, level);
            this.xpReward = 0;
            this.setPersistenceRequired();
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(BetrayalMod.KNIFE.get()));
            this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        }

        public static AttributeSupplier.Builder attrs() {
            return Mob.createMobAttributes()
                    .add(Attributes.MAX_HEALTH, 100.0)
                    .add(Attributes.MOVEMENT_SPEED, 0.3)
                    .add(Attributes.ATTACK_DAMAGE, 5.0)
                    .add(Attributes.FOLLOW_RANGE, 48.0)
                    .add(Attributes.KNOCKBACK_RESISTANCE, 0.5);
        }

        @Override
        protected void defineSynchedData() {
            super.defineSynchedData();
            this.entityData.define(OWNER, Optional.empty());
        }

        public UUID getOwnerUuid() {
            return this.entityData.get(OWNER).orElse(null);
        }

        public void setOwner(UUID id) {
            this.entityData.set(OWNER, Optional.ofNullable(id));
        }

        public int getMode() {
            return mode;
        }

        public void setMode(int m) {
            this.mode = m;
        }

        private ServerPlayer ownerPlayer() {
            UUID id = getOwnerUuid();
            if (id != null && level() instanceof ServerLevel sl) {
                Player pl = sl.getPlayerByUUID(id);
                if (pl instanceof ServerPlayer sp) {
                    return sp;
                }
            }
            return null;
        }

        @Override
        protected void registerGoals() {
            this.goalSelector.addGoal(0, new FloatGoal(this));
            this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, true));
            this.goalSelector.addGoal(2, new FollowOwnerGoal(this));
            this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F));
        }

        @Override
        public boolean removeWhenFarAway(double d) {
            return false;
        }

        @Override
        public boolean hurt(DamageSource src, float amount) {
            if (src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                return super.hurt(src, amount);
            }
            if (mode != 2) {
                return false;
            }
            if (src.getEntity() instanceof ServerPlayer sp) {
                if (sp.getMainHandItem().is(BetrayalMod.KNIFE.get())) {
                    return super.hurt(src, amount);
                }
                sp.displayClientMessage(Component.literal("Only the knife can hurt him.").withStyle(ChatFormatting.DARK_GRAY), true);
            }
            return false;
        }

        @Override
        public void remove(Entity.RemovalReason reason) {
            bar.removeAllPlayers();
            super.remove(reason);
        }

        @Override
        public void tick() {
            super.tick();
            if (level().isClientSide) {
                return;
            }
            ServerPlayer o = ownerPlayer();
            if (o == null || !o.isAlive() || o.level() != level()) {
                discard();
                return;
            }
            if (mode != 2) {
                getLookControl().setLookAt(o, 30.0F, 30.0F);
                return;
            }
            setTarget(o);
            bar.addPlayer(o);
            bar.setProgress(Math.max(0.0F, getHealth() / getMaxHealth()));

            float r = getHealth() / getMaxHealth();
            String me = o.getName().getString();
            BlockPos cp = posOf(st(o), "crescent");
            boolean near = cp != null && cp.distSqr(blockPosition()) < 144;
            if (near && tickCount % 20 == 0) {
                addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 0, false, false));
            }
            if (r <= 0.66F && phase < 2) {
                phase = 2;
                say(o, me, "You can't hit what you can't see.", ChatFormatting.WHITE);
            }
            if (r <= 0.33F && phase < 3) {
                phase = 3;
                say(o, me, "Every time you swing, you remember him. Good.", ChatFormatting.WHITE);
            }
            if (r <= 0.10F && !saidLast) {
                saidLast = true;
                say(o, me, "Then finish it.", ChatFormatting.WHITE);
            }
            if (phase >= 3 && tickCount % 20 == 0) {
                addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 0, false, false));
            }
            if (phase >= 2 && !near && tickCount % 120 == 0) {
                Vec3 back = Vec3.directionFromRotation(0, o.getYRot() + 180.0F).scale(2.0);
                teleportTo(o.getX() + back.x, o.getY(), o.getZ() + back.z);
                o.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
                playSound(SoundEvents.ENDERMAN_TELEPORT, 1.0F, 0.6F);
            }
        }

        @Override
        public void addAdditionalSaveData(CompoundTag t) {
            super.addAdditionalSaveData(t);
            t.putInt("Mode", mode);
            UUID id = getOwnerUuid();
            if (id != null) {
                t.putUUID("Owner", id);
            }
        }

        @Override
        public void readAdditionalSaveData(CompoundTag t) {
            super.readAdditionalSaveData(t);
            mode = t.getInt("Mode");
            if (t.hasUUID("Owner")) {
                setOwner(t.getUUID("Owner"));
            }
        }

        static class FollowOwnerGoal extends Goal {
            private final FutureEntity mob;

            FollowOwnerGoal(FutureEntity mob) {
                this.mob = mob;
                setFlags(EnumSet.of(Goal.Flag.MOVE));
            }

            @Override
            public boolean canUse() {
                ServerPlayer o = mob.ownerPlayer();
                return mob.mode != 2 && o != null && mob.distanceToSqr(o) > 16.0;
            }

            @Override
            public boolean canContinueToUse() {
                ServerPlayer o = mob.ownerPlayer();
                return mob.mode != 2 && o != null && mob.distanceToSqr(o) > 4.0;
            }

            @Override
            public void tick() {
                ServerPlayer o = mob.ownerPlayer();
                if (o == null) {
                    return;
                }
                if (mob.distanceToSqr(o) > 400.0) {
                    mob.teleportTo(o.getX(), o.getY(), o.getZ());
                } else {
                    mob.getNavigation().moveTo(o, 1.2);
                }
            }
        }
    }

    /** Draws the Guardian with the owner's own skin: an exact copy of the player. */
    public static class FutureRenderer extends HumanoidMobRenderer<FutureEntity, PlayerModel<FutureEntity>> {
        private final PlayerModel<FutureEntity> wide;
        private final PlayerModel<FutureEntity> slim;

        public FutureRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
            this.wide = this.model;
            this.slim = new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER_SLIM), true);
        }

        private static PlayerInfo info(FutureEntity e) {
            UUID id = e.getOwnerUuid();
            ClientPacketListener cp = Minecraft.getInstance().getConnection();
            return (id != null && cp != null) ? cp.getPlayerInfo(id) : null;
        }

        @Override
        public void render(FutureEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
            PlayerInfo i = info(e);
            this.model = (i != null && "slim".equals(i.getModelName())) ? slim : wide;
            super.render(e, yaw, partial, ps, buf, light);
        }

        @Override
        public ResourceLocation getTextureLocation(FutureEntity e) {
            PlayerInfo i = info(e);
            return i != null ? i.getSkinLocation() : DefaultPlayerSkin.getDefaultSkin();
        }
    }

    // =====================================================================================
    //  Game events
    // =====================================================================================

    @Mod.EventBusSubscriber(modid = MODID)
    public static class Events {

        @SubscribeEvent(priority = EventPriority.HIGHEST)
        public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
            if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) {
                return;
            }
            runScripts(p);
            if (p.tickCount % 20 != 0 || !p.isAlive()) {
                return;
            }
            ServerLevel l = p.serverLevel();
            if (l.dimension() != Level.OVERWORLD) {
                return;
            }
            CompoundTag d = p.getPersistentData();
            CompoundTag st = st(p);
            stamp(p);

            long gt = l.getGameTime();
            long dt = l.getDayTime();
            long tod = dt % 24000L;
            long day = dt / 24000L;
            boolean night = tod >= 13000L && tod < 23000L;

            // ----- Bedrock house: comes back by day / once the Crescent is in place / after the ending
            boolean crescent = crescentOk(l, st);
            Backup bk = Backup.get(l);
            if (!bk.map.isEmpty() && (tod < 12000L || crescent || st.getBoolean("restored"))) {
                restoreHouse(l);
            }

            if (st.getBoolean("restored")) {
                for (BetrayalEntity b : l.getEntitiesOfClass(BetrayalEntity.class, p.getBoundingBox().inflate(64),
                        b -> p.getUUID().equals(b.getOwnerId()))) {
                    if (!b.getTags().contains(TAG_RESTORED)) {
                        b.addTag(TAG_RESTORED);
                    }
                }
                return;
            }
            if (!d.getBoolean("betrayal_killed")) {
                return;
            }

            // ----- count the nights since the betrayal
            if (night && st.getLong("nd") != day + 1L) {
                st.putLong("nd", day + 1L);
                int n = st.getInt("night") + 1;
                st.putInt("night", n);
                onNight(p, l, st, n, gt);
            }
            int n = st.getInt("night");
            int stage = st.getInt("stage");

            // ----- the Bedrock house (odd nights from night 3, only while you are away from home)
            BlockPos home = posOf(st, "home");
            if (stage == 0 && night && n >= 3 && n % 2 == 1 && !crescent && home != null && bk.map.isEmpty()
                    && st.getInt("bdNight") != n && l.isLoaded(home)) {
                double dx = p.getX() - home.getX();
                double dz = p.getZ() - home.getZ();
                if (dx * dx + dz * dz > 40.0 * 40.0) {
                    convertHouse(l, home, null);
                    st.putInt("bdNight", n);
                }
            }

            // ----- the truth comes out
            BlockPos cp = posOf(st, "crescent");
            if (stage == 0 && night && n >= REVEAL_NIGHT && crescent && cp != null && cp.distSqr(p.blockPosition()) < 256) {
                startReveal(p, l, st);
                return;
            }
            if (stage == 1) {
                suppressGhost(p, l);
                if (!hasScript(p)) {
                    startReveal(p, l, st);
                }
                return;
            }
            if (stage == 2) {
                suppressGhost(p, l);
                boolean has = false;
                for (FutureEntity f : futures(p, l)) {
                    if (f.getMode() == 2) {
                        has = true;
                    }
                }
                if (!has) {
                    FutureEntity f = spawnFuture(p, l, 2);
                    if (f != null) {
                        f.setMode(2);
                    }
                }
                return;
            }
            if (stage == 3) {
                suppressGhost(p, l);
                if (!hasScript(p)) {
                    finishEnding(p);
                }
                return;
            }

            // ----- the Guardian (every 20 minutes, protects for 5)
            if (n >= FUTURE_NIGHT) {
                if (!st.contains("guardNext")) {
                    st.putLong("guardNext", gt);
                }
                boolean active = gt < st.getLong("guardEnd");
                if (active) {
                    suppressGhost(p, l);
                    if (futures(p, l).isEmpty()) {
                        spawnFuture(p, l, 0);
                    }
                } else if (st.getBoolean("guardOn")) {
                    endGuard(p, l, st);
                } else if (gt >= st.getLong("guardNext")) {
                    startGuard(p, l, st, gt);
                }
            }
        }

        /** Marks every Crescent in the inventory as silver (boy) or gold (girl). */
        static void stamp(ServerPlayer p) {
            String g = st(p).getString("gender");
            Inventory inv = p.getInventory();
            boolean unstamped = false;
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (s.is(CRESCENT_ITEM) && (!s.hasTag() || !s.getTag().contains("Maker"))) {
                    if (g.isEmpty()) {
                        unstamped = true;
                    } else {
                        CompoundTag t = s.getOrCreateTag();
                        t.putString("Maker", g);
                        t.putBoolean("Gold", g.equals("girl"));
                    }
                }
            }
            if (unstamped && p.tickCount % 400 == 0) {
                promptGender(p);
            }
        }

        @SubscribeEvent
        public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
            if (e.getEntity() instanceof ServerPlayer p && !st(p).contains("gender")) {
                promptGender(p);
            }
        }

        @SubscribeEvent
        public static void onClone(PlayerEvent.Clone e) {
            CompoundTag old = e.getOriginal().getPersistentData();
            if (old.contains("betrayal_story", 10)) {
                e.getEntity().getPersistentData().put("betrayal_story", old.getCompound("betrayal_story").copy());
            }
        }

        @SubscribeEvent
        public static void onPlace(BlockEvent.EntityPlaceEvent e) {
            if (!(e.getLevel() instanceof ServerLevel l) || !(e.getEntity() instanceof ServerPlayer p)) {
                return;
            }
            BlockState s = e.getPlacedBlock();
            CompoundTag st = st(p);
            BlockPos pos = e.getPos();
            if (s.getBlock() instanceof DoorBlock || s.getBlock() instanceof BedBlock) {
                if (!st.contains("home") && l.dimension() == Level.OVERWORLD) {
                    st.putLong("home", pos.asLong());
                }
                return;
            }
            if (s.getBlock() == CRESCENT) {
                if (l.dimension() != Level.OVERWORLD || !enclosed(l, pos)) {
                    e.setCanceled(true);
                    p.displayClientMessage(Component.literal("It must be placed inside your home.").withStyle(ChatFormatting.DARK_GRAY), true);
                    return;
                }
                st.putLong("crescent", pos.asLong());
                if (!st.contains("home")) {
                    st.putLong("home", pos.asLong());
                }
                sound(l, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, SoundEvents.AMETHYST_BLOCK_CHIME, 1.5F, 0.6F);
                narrate(p, "Something old settles into the house.");
            }
        }

        @SubscribeEvent
        public static void onAttack(LivingAttackEvent e) {
            if (e.getEntity() instanceof BetrayalEntity b && b.getTags().contains(TAG_RESTORED)
                    && !e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                e.setCanceled(true);
            }
        }

        @SubscribeEvent
        public static void onDeath(LivingDeathEvent e) {
            if (e.getEntity() instanceof FutureEntity f && f.getMode() == 2 && f.level() instanceof ServerLevel sl) {
                UUID id = f.getOwnerUuid();
                Player pl = id == null ? null : sl.getPlayerByUUID(id);
                if (pl instanceof ServerPlayer sp && st(sp).getInt("stage") == 2) {
                    startEnding(sp);
                }
            }
        }

        @SubscribeEvent
        public static void onCommands(RegisterCommandsEvent e) {
            e.getDispatcher().register(Commands.literal("betrayal")
                    .then(Commands.literal("gender")
                            .then(Commands.literal("boy").executes(c -> setGender(c.getSource(), "boy")))
                            .then(Commands.literal("girl").executes(c -> setGender(c.getSource(), "girl"))))
                    .then(Commands.literal("night").requires(s -> s.hasPermission(2))
                            .then(Commands.argument("n", IntegerArgumentType.integer(0, 40))
                                    .executes(c -> setNight(c.getSource(), IntegerArgumentType.getInteger(c, "n"))))));
        }

        static int setGender(CommandSourceStack src, String g) throws CommandSyntaxException {
            ServerPlayer p = src.getPlayerOrException();
            st(p).putString("gender", g);
            src.sendSuccess(() -> Component.literal(g.equals("girl")
                    ? "Noted. Your Crescent & Star will be gold." : "Noted. Your Crescent & Star will be silver."), false);
            return 1;
        }

        static int setNight(CommandSourceStack src, int n) throws CommandSyntaxException {
            ServerPlayer p = src.getPlayerOrException();
            CompoundTag st = st(p);
            st.putInt("night", n);
            st.putLong("guardNext", p.serverLevel().getGameTime());
            st.putLong("guardEnd", 0L);
            src.sendSuccess(() -> Component.literal("Story night set to " + n + "."), false);
            return 1;
        }
    }
}
